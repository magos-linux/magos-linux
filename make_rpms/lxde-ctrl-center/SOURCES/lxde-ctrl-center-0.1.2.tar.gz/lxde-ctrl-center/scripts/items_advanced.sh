#!/bin/bash

echo "Creating share/lxde-ctrl-center/items/advanced..."

cd ../share/lxde-ctrl-center/items

rm -f ./advanced.tmp

cp -f ./x0001x ./x0001x.tmp
cp -f ./x0002x ./x0002x.tmp
cp -f ./x0003x ./x0003x.tmp
cp -f ./x0004x ./x0004x.tmp
cp -f ./x0005x ./x0005x.tmp
cp -f ./x0006x ./x0006x.tmp

sed -i -e "/^{/d" ./x0001x.tmp
sed -i -e "/^}/d" ./x0001x.tmp
sed -i -e 's/},/}/g' ./x0001x.tmp

sed -i -e "/^{/d" ./x0002x.tmp
sed -i -e "/^}/d" ./x0002x.tmp
sed -i -e 's/},/}/g' ./x0002x.tmp

sed -i -e "/^{/d" ./x0003x.tmp
sed -i -e "/^}/d" ./x0003x.tmp
sed -i -e 's/},/}/g' ./x0003x.tmp

sed -i -e "/^{/d" ./x0004x.tmp
sed -i -e "/^}/d" ./x0004x.tmp
sed -i -e 's/},/}/g' ./x0004x.tmp

sed -i -e "/^{/d" ./x0005x.tmp
sed -i -e "/^}/d" ./x0005x.tmp
sed -i -e 's/},/}/g' ./x0005x.tmp

sed -i -e "/^{/d" ./x0006x.tmp
sed -i -e "/^}/d" ./x0006x.tmp
sed -i -e 's/},/}/g' ./x0006x.tmp

echo "{" > ./advanced.tmp
cat ./x0001x.tmp >> ./advanced.tmp
cat ./x0002x.tmp >> ./advanced.tmp
cat ./x0003x.tmp >> ./advanced.tmp
cat ./x0004x.tmp >> ./advanced.tmp
cat ./x0005x.tmp >> ./advanced.tmp
cat ./x0006x.tmp >> ./advanced.tmp
sed -i -e 's/}/},/g' ./advanced.tmp
A=`tail -1 ./advanced.tmp`
tail -1 ./advanced.tmp > ./end.tmp
sed -i -e 's/},/}/g' ./end.tmp
B=`cat ./end.tmp`
C=`cat ./end.tmp|grep {|grep }`
if [ ! "$C" = "" ]
then
  sed -i -e "s|$A|$B|g" ./advanced.tmp
fi
echo "}" >> ./advanced.tmp

rm -f ./end.tmp
cp -f ./advanced.tmp ./advanced
rm -f ./advanced.tmp
rm -f ./x0001x.tmp
rm -f ./x0002x.tmp
rm -f ./x0003x.tmp
rm -f ./x0004x.tmp
rm -f ./x0005x.tmp
rm -f ./x0006x.tmp

if [ "$C" = "" ]
then
  echo "Error creating ./share/lxde-ctrl-center/items/advanced with correct sintax."
  exit 1
fi

echo "Success."
