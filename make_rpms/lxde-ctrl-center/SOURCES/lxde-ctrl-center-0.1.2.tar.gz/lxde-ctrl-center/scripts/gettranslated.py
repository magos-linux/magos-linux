#!/usr/bin/env python
# _*_ coding: utf-8 _*_

import os, sys

if len(sys.argv) != 3:
	sys.stderr.write("Usage: %s <string to translate> <path to locales>\n" % sys.argv[0])
	raise SystemExit(1)

s = sys.argv[1]
lang_dir = os.path.abspath(sys.argv[2])


def getFromFile(s, fname):

	tr_dic = {}
	tr = ''
	lang = os.path.splitext(os.path.basename(fname))[0]
	with open(os.path.abspath(fname), 'r') as desc:
		lines = desc.readlines()
	for line in lines:
		if line.startswith('msgid') and s in line:
			if line.split(' ', 1)[1].strip().strip('\"\'') == s:
				for i in range(lines.index(line) + 1, len(lines)):
					if lines[i].startswith('msgstr'):
						tr = lines[i].strip().split(' ', 1)[1].strip('\"\'')
						break
	if tr:
		tr_dic[lang] = tr
	else:
		tr_dic[lang] = s
	return tr_dic



def gettranslated(s, lang_dir):

	tr_dic = {}

	try:
		for dirpath, dirnames, filenames in os.walk(lang_dir):
			for f in filenames:
				full_name = os.path.join(lang_dir, f)
				if os.path.splitext(f)[1] == '.po':
					tr = ''
					lang = os.path.splitext(f)[0]
					with open(full_name, 'r') as desc:
						lines = desc.readlines()
					for line in lines:
						if line.startswith('msgid') and s in line:
							if line.split(' ', 1)[1].strip().strip('\"\'') == s:
								for i in range(lines.index(line) + 1, len(lines)):
									if lines[i].startswith('msgstr'):
										tr = lines[i].strip().split(' ', 1)[1].strip('\"\'')
										break
					if tr:
						tr_dic[lang] = tr
					else:
						tr_dic[lang] = s
		return tr_dic
	except:
		pass



if __name__ == '__main__':

	if os.path.isfile(lang_dir):
		res = getFromFile(s, lang_dir)
		print (res.values()[0])

	elif os.path.isdir(lang_dir):
		res = gettranslated(s, lang_dir)
		for key in res:
			print ("%s : %s" % (key, res[key]))

