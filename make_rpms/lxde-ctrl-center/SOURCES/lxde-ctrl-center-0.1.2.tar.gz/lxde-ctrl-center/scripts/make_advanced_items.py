#!/usr/bin/env python
# _*_ coding: utf-8 _*_

import os
import json

print ("Creating share/lxde-ctrl-center/items/advanced...")
ITEMS_DIR = '../share/lxde-ctrl-center/items'

advanced_dic = {}

os.chdir(ITEMS_DIR)
for fname in os.listdir(os.curdir):
	if fname != 'advanced':
		with open(fname, 'r') as f:
			advanced_dic.update(json.load(f))
with open('advanced', 'w') as f:
	json.dump(advanced_dic, f, indent = 4)

print ("Success.")
