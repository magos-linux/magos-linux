#!/bin/bash

echo "Creating share/applications/lxde-ctrl-center.desktop..."

cd ../po

rm -f ./tmp.txt

dir -1|grep -v .pot|cut -d "." --fields=1|while read LANG
do
  A=`../scripts/gettranslated.py "LXDE Control Center" ./$LANG.po`
  echo $LANG : "LXDE Control Center" : $A
  B=`../scripts/gettranslated.py "Configuration tool for LXDE" ./$LANG.po`
  echo $LANG : "Configuration tool for LXDE" : $B
  echo Name[$LANG]=$A >> ./tmp.txt
  echo Comment[$LANG]=$B >> ./tmp.txt
done

cd ..

BUILD_PKG=0
for P in "$@"
do
  if [ "$P" = "build_pkg" ]
  then
    BUILD_PKG=1
  fi
done

if [ "$BUILD_PKG" = "0" ]
then
  if [ ! -f "./share/applications/lxde-ctrl-center.desktop.old" ]
  then
    cp -f ./share/applications/lxde-ctrl-center.desktop ./share/applications/lxde-ctrl-center.desktop.old
  fi
else
  echo "Creating lxde-ctrl-center.desktop.old was skipped, because you used ./make with option build_pkg"
fi

C=`cat ./share/applications/lxde-ctrl-center.desktop|grep "Центр управления LXDE"`
if [ "$C" = "" ]
then
  cat ./po/tmp.txt >> ./share/applications/lxde-ctrl-center.desktop
fi

rm -f ./po/tmp.txt

echo "Success."
