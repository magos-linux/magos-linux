#!/bin/bash

cd ..

echo "Creating po/lxde-ctrl-center.pot..."

xgettext --language=Python --keyword=_ --output=po/lxde-ctrl-center.pot share/lxde-ctrl-center/control-center.py translations.py --from-code=utf-8

cd po

dir -1|grep -v .pot|while read PO
do
  msgmerge $PO lxde-ctrl-center.pot -o $PO
done

echo "Success."
