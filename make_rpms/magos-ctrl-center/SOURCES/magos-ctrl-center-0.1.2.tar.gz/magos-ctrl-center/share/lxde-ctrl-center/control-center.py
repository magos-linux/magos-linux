#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
 Based on tuquito-control-center: https://github.com/tuquito/tuquito-control-center
 by Mario Colque <mario@tocuito.org.ar>
 
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; version 3 of the License.
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA.
"""

import gtk
import os
import subprocess
import gettext
import webkit
import string
import json
import sys


# LIB_DIR = '/usr/share/lxde-ctrl-center'
LIB_DIR = os.path.abspath(os.path.dirname(sys.argv[0]))
HOME_DIR = os.path.expanduser('~')
LOCALE_DIR = os.path.join(LIB_DIR, '../locale/')
SU_FRONTENDS = ['gksu', 'gksudo', 'beesu', 'kdesu', 'xroot']

if os.geteuid() == 0:
    OWNER = 'root'
else:
    OWNER = 'user'

# i18n
gettext.install('lxde-ctrl-center', LOCALE_DIR)

class MessageDialog:
    def __init__(self, title, message, style):
        self.title = title
        self.message = message
        self.style = style

    def show(self):
        dialog = gtk.MessageDialog(None, gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT, self.style, gtk.BUTTONS_OK)
        dialog.set_markup(_('<b>Error:</b>'))
        dialog.set_icon_name('preferences-system')
        dialog.format_secondary_markup(self.message)
        dialog.set_title(_('LXDE Control Center'))
        dialog.set_position(gtk.WIN_POS_CENTER)
        dialog.run()
        dialog.destroy()

class ControlCenter():
    def __init__(self):
        self.builder = gtk.Builder()
        self.builder.add_from_file(os.path.join(LIB_DIR, 'control-center.glade'))
        self.window = self.builder.get_object('window')
        self.builder.get_object('window').set_title(_('LXDE Control Center'))
        self.edit_handler_id = False
        self.add_handler_id = False
        self.items_cache = []
        self.items_advanced_cache = []
        self.theme = gtk.icon_theme_get_default()
        self.read_preferences(self)
        self.read_strings(self)
        # self.window.set_resizable(True)

        # Define treeview
        self.treeview_items = self.builder.get_object('treeview_items')
        self.column1 = gtk.TreeViewColumn(_('Item'), gtk.CellRendererText(), text=0)
        self.column1.set_sort_column_id(0)
        self.column1.set_resizable(True)
        self.column2 = gtk.TreeViewColumn(_('Command'), gtk.CellRendererText(), text=1)
        self.column2.set_sort_column_id(1)
        self.column2.set_resizable(True)
        self.treeview_items.append_column(self.column1)
        self.treeview_items.append_column(self.column2)
        self.treeview_items.set_headers_clickable(True)
        self.treeview_items.set_reorderable(False)
        self.treeview_items.show()

        self.builder.get_object('window').connect('destroy', gtk.main_quit)
        self.browser = webkit.WebView()
        self.builder.get_object('window').add(self.browser)
        self.browser.connect('button-press-event', lambda w, e: e.button == 3)

        self.set_options_status()

        if not self.mode:
            self.load_advanced()

        template = self.get_template()
        html = string.Template(template).safe_substitute(self.text)
        self.browser.load_html_string(html, "file://%s/" % LIB_DIR)
        self.browser.connect('title-changed', self.title_changed)
        self.window.show_all()

    def set_options_status(self):
        if self.mode:
            self.text['input_mode_id'] = 'checked="checked"'
            self.text['input_mode'] = ''
        else:
            self.text['input_mode_id'] = ''
            self.text['input_mode'] = 'checked="checked"'
        if self.visual_effects:
            self.text['input_visual'] = 'checked="checked"'
        else:
            self.text['input_visual'] = ''

    def get_template(self):
        if self.visual_effects and self.mode:
            template_file = os.path.join(LIB_DIR, 'frontend/default.html')
        elif not self.visual_effects and self.mode:
            template_file = os.path.join(LIB_DIR, 'frontend/default-faster.html')
        elif self.visual_effects and not self.mode:
            template_file = os.path.join(LIB_DIR, 'frontend/advanced.html')
        else:
            template_file = os.path.join(LIB_DIR, 'frontend/advanced-faster.html')
        with open(template_file, 'r') as f:
            template = f.read()
        return template

    def change_skin(self, widget):
        self.set_options_status()
        self.items_cache = []
        template = self.get_template()
        if not self.mode:
            self.load_advanced()
        html = string.Template(template).safe_substitute(self.text)
        self.browser.load_html_string(html, "file://%s/" % LIB_DIR)

    def read_preferences(self, widget):
        self.pref_file = os.path.join(HOME_DIR, '.lxde-ctrl-center/preferences')
        if os.path.isfile(self.pref_file):
            with open(self.pref_file, 'r') as pref_file:
                dic = json.load(pref_file)
            self.mode = bool(dic['mode'])
            self.visual_effects = bool(dic['visual_effects'])
        else:
            self.mode = True
            self.visual_effects = True
            
    def read_strings(self, widget):
        self.string_file = os.path.join(LIB_DIR, 'strings/y0001y')
        if os.path.isfile(self.string_file):
            with open(self.string_file, 'r') as string_file:
                string = json.load(string_file)
        for k in string:
           self.text = {}
           self.text['x0001x'] = _(string['x0001x'])
           self.text['x0002x'] = _(string['x0002x'])
           self.text['x0003x'] = _(string['x0003x'])
           self.text['x0004x'] = _(string['x0004x'])
           self.text['x0005x'] = _(string['x0005x'])
           self.text['x0006x'] = _(string['x0006x'])
           self.text['x0007x'] = _(string['x0007x'])
           self.text['x0008x'] = _(string['x0008x'])
           self.text['x0009x'] = _(string['x0009x'])
           self.text['x0010x'] = _(string['x0010x'])
           self.text['x0011x'] = _(string['x0011x'])
           self.text['x0012x'] = _(string['x0012x'])
           self.text['x0013x'] = _(string['x0013x'])
           self.text['x0014x'] = _(string['x0014x'])
           self.text['x0015x'] = _(string['x0015x'])
           self.text['x0016x'] = _(string['x0016x'])
           self.text['x0017x'] = _(string['x0017x'])
           self.text['x0018x'] = _(string['x0018x'])
           self.text['x0019x'] = _(string['x0019x'])
           self.text['x0020x'] = _(string['x0020x'])
           self.text['x0021x'] = _(string['x0021x'])
           self.text['x0022x'] = _(string['x0022x'])
           self.text['x0023x'] = _(string['x0023x'])
           self.text['x0024x'] = _(string['x0024x'])
           self.text['back'] = _('Back to menu')
           self.text['options'] = _('Options')
           self.text['mode'] = _('Mode')
           self.text['advanced_mode'] = _('Advanced mode')
           self.text['normal_mode'] = _('Normal mode')
           self.text['visual'] = _('Visual effects')
           self.text['nice'] = _('Use visual effects (slower)')
           self.text['note_visual'] = _('If you want better performance (faster), disable visual effects.')
           self.text['apply'] = _('Apply')
           self.text['edit_items'] = _('Edit items')           

    def save_preferences(self, widget):
        if self.mode == "true":
            self.mode = True
        else:
            self.mode = False
        if self.visual_effects == "true":
            self.visual_effects = True
        else:
            self.visual_effects = False
        dic = dict([("mode", self.mode), ("visual_effects", self.visual_effects)])
        with open(self.pref_file, 'w') as pref_file:
            json.dump(dic, pref_file, indent = 4)

    def items_window(self, widget):
        self.model = gtk.TreeStore(str, str, str)
        self.model.set_sort_column_id(0, gtk.SORT_ASCENDING)
        self.item_window = self.builder.get_object('items')
        self.item_window.set_title(_('Add or remove items'))
        self.builder.get_object('toolbutton_restore').set_label(_('Restore original'))
        with open(self.category_file, 'r') as items_file:
            dic = json.load(items_file)
        for k in dic:
            command = k
            title = dic[k]['title']
            owner = dic[k]['owner']
            icon = dic[k]['icon']
            if OWNER == 'root' and owner == 'user':
                continue
            iter = self.model.insert_before(None, None)
            self.model.set_value(iter, 0, _(title))
            self.model.set_value(iter, 1, command)
            self.model.set_value(iter, 2, icon)
        self.treeview_items.set_model(self.model)
        del self.model
        self.builder.connect_signals(self)
        self.item_window.show()

    def add_item(self, widget):
        self.builder.get_object('title').set_text('')
        self.builder.get_object('code').set_text('')
        self.builder.get_object('icon').set_text('applications-other')
        self.builder.get_object('add_item').set_title(_('Add item'))
        if self.edit_handler_id:
            self.builder.get_object('save').disconnect(self.edit_handler_id)
        if self.add_handler_id:
            self.builder.get_object('save').disconnect(self.add_handler_id)
        self.add_handler_id = self.builder.get_object('save').connect('clicked', self.save_item)
        self.builder.get_object('ltitle').set_label(_('Title: (eg Change Wallpaper)'))
        self.builder.get_object('lcode').set_label(_('Command app:'))
        self.builder.get_object('licon').set_label(_('Icon file:'))
        self.builder.get_object('lexpander').set_label(_('Options icon'))
        self.builder.get_object('add_item').show()

    def close_add_item(self, widget, data=None):
        self.builder.get_object('add_item').hide()
        return True

    def close_items(self, widget, data=None):
        self.builder.get_object('items').hide()
        return True

    def save_item(self, widget):
        title = self.builder.get_object('title').get_text().strip()
        command = self.builder.get_object('code').get_text().strip()
        if not isinstance(command, unicode):
            command = command.decode('utf-8')
        icon = self.builder.get_object('icon').get_text().strip()
        if not os.path.isfile(self.home_file):
            os.system('cp %s %s' % (self.category_file, self.home_file))
        self.category_file = self.home_file

        errors = []
        if not title:
            errors.append(_('Title is empty'))
        if (not command) or (command.strip() in SU_FRONTENDS):
            errors.append(_('Command is empty'))
        elif not self.commandSeek(command.split()[0].strip()):
            errors.append(_('The command <b>%s</b> is not found or not is executable') % command)
        
        if not errors:
            with open(self.category_file, 'r') as items_file:
                dic = json.load(items_file)
            for k in dic:
                if k == command:
                    errors.append(_('The command <b>%s</b> already exists') % command)
                    break
                if dic[k]['title'] == title:
                    errors.append(_('The title <b>%s</b> already exists') % title)
                    break
        if not errors:
            if not os.path.isfile(icon):
               icon = LIB_DIR + '/icons/' + icon
            if not os.path.isfile(icon):
                icon = os.path.join(LIB_DIR, 'frontend/images/applications-other.svg')
            dic[command] = dict([('title', title), ('owner', OWNER), ('icon', icon)])
            self.model = self.treeview_items.get_model()
            iter = self.model.insert_before(None, None)
            self.model.set_value(iter, 0, title)
            self.model.set_value(iter, 1, command)
            self.model.set_value(iter, 2, icon)
            with open(self.category_file, 'w') as items_file:
                json.dump(dic, items_file, indent = 4)
            self.browser.execute_script("addItem('%s','%s','%s','%s')" % (_(title), command, self.category, icon))
            self.browser.execute_script("setContent('" + self.category + "')")
            self.items_cache.append(command)
            self.close_add_item(self)
            del self.model
        else:
            message = MessageDialog('Error', ('%s') % '\n'.join(errors), gtk.MESSAGE_ERROR)
            message.show()

    def remove_item(self, widget):
        selection = self.treeview_items.get_selection()
        (self.model, iter) = selection.get_selected()
        if not os.path.isfile(self.home_file):
            os.system('cp %s %s' % (self.category_file,self.home_file))
        self.category_file = self.home_file
        if iter != None:
            command = self.model.get_value(iter, 1)
            if not isinstance(command, unicode):
                command = command.decode('utf-8')
            with open(self.category_file) as items_file:
                dic = json.load(items_file)
            dic.pop(command)
            items_file = open(self.category_file, 'w')
            json.dump(dic, items_file, indent = 4)
            items_file.close()
            self.model.remove(iter)
            self.browser.execute_script("removeItem('" + command + "', '" + self.category + "')")
            self.items_cache.remove(command)

    def restore_items(self, widget):
        self.browser.execute_script("removeItem('all-items', '" + self.category + "')")
        os.system('cp %s %s' % (self.base_file, self.home_file))
        with open(self.category_file, 'r') as items_file:
            dic = json.load(items_file)
        for k in dic:
            command = k
            title = dic[k]['title']
            icon = dic[k]['icon']
            owner = dic[k]['owner']
            if OWNER == 'root' and owner == 'user':
                continue
            if not os.path.isfile(icon):
               icon = LIB_DIR + '/icons/' + icon
            if not os.path.isfile(icon):
                icon = os.path.join(LIB_DIR, 'frontend/images/applications-other.svg')
            self.browser.execute_script("addItem('%s','%s','%s','%s')" % (_(title), command, self.category, icon))
            if command not in self.items_cache:
                self.items_cache.append(command)
        self.browser.execute_script("setContent('" + self.category + "')")
        self.close_items(self)

    def edit_item(self, widget):
        selection = self.treeview_items.get_selection()
        (self.model, self.iter) = selection.get_selected()
        if self.iter != None:
            title = self.model.get_value(self.iter, 0)
            command = self.model.get_value(self.iter, 1)
            if not isinstance(command, unicode):
                command = command.decode('utf-8')
            icon = self.model.get_value(self.iter, 2)
            self.builder.get_object('title').set_text(title)
            self.builder.get_object('code').set_text(command)
            self.builder.get_object('icon').set_text(icon)
            self.builder.get_object('add_item').set_title(_('Edit item'))
            if self.add_handler_id:
                self.builder.get_object('save').disconnect(self.add_handler_id)
            if self.edit_handler_id:
                self.builder.get_object('save').disconnect(self.edit_handler_id)
            self.edit_handler_id = self.builder.get_object('save').connect('clicked', self.save_edited_item)
            self.builder.get_object('ltitle').set_label(_('Title: (eg Change Wallpaper)'))
            self.builder.get_object('lcode').set_label(_('Command app:'))
            self.builder.get_object('licon').set_label(_('Icon file:'))
            self.builder.get_object('lexpander').set_label(_('Options icon'))
            self.builder.get_object('add_item').show()
            self.old_command = command

    def save_edited_item(self, widget):
        title = self.builder.get_object('title').get_text().strip()
        new_command = self.builder.get_object('code').get_text().strip()
        if not isinstance(new_command, unicode):
            new_command = new_command.decode('utf-8')
        icon = self.builder.get_object('icon').get_text().strip()
        if not os.path.isfile(self.home_file):
            os.system('cp %s %s' % (self.category_file,self.home_file))
        self.category_file = self.home_file

        errors = []
        if not title:
            errors.append(_('Title is empty'))
        if (not new_command) or (new_command.strip() in SU_FRONTENDS):
            errors.append(_('Command is empty'))
        elif not self.commandSeek(new_command.split()[0].strip()):
            errors.append(_('The command <b>%s</b> is not found or not is executable') % new_command)

        if not errors:
            if not os.path.isfile(icon):
               icon = LIB_DIR + '/icons/' + icon
            if not os.path.isfile(icon):
                icon = os.path.join(LIB_DIR, 'frontend/images/applications-other.svg')
            with open(self.category_file, 'r') as items_file:
                dic = json.load(items_file)
                        
            for k in dic:
                if (k == new_command) and (self.old_command != new_command):
                    errors.append(_('The command <b>%s</b> already exists') % new_command)
                    break
                if (dic[k]['title'] == title) and (k != self.old_command):
                    errors.append(_('The title <b>%s</b> already exists') % title)
                    break

        if not errors:
            dic.pop(self.old_command)
            dic[new_command] = dict([('owner', OWNER), ('title', title), ('icon', icon)])

            self.model.set_value(self.iter, 0, title)
            self.model.set_value(self.iter, 1, new_command)
            self.model.set_value(self.iter, 2, icon)
            with open(self.category_file, 'w') as items_file:
                json.dump(dic, items_file, indent = 4)
            self.browser.execute_script("editItem('%s', '%s', '%s', '%s')" % (_(title), self.old_command, new_command, icon))
            self.browser.execute_script("setContent('" + self.category + "')")
            if new_command not in self.items_cache:
                self.items_cache.append(new_command)
            self.close_add_item(self)
            del self.model
        else:
            message = MessageDialog('Error', ('%s') % '\n'.join(errors), gtk.MESSAGE_ERROR)
            message.show()

    def search_icon(self, widget):
        self.builder.get_object('filechooserdialog').set_title(_('LXDE Control Center'))
        self.builder.get_object('filechooserdialog').set_action(gtk.FILE_CHOOSER_ACTION_OPEN)
        self.builder.get_object('filechooserdialog').show()

    def on_search_ok(self, widget, data=None):
        icon_file = self.builder.get_object('filechooserdialog').get_filename()
        if icon_file:
            self.builder.get_object('icon').set_text(icon_file.strip())
            self.search_close(self)
        else:
            print (_('Icon is not selected'))

    def search_close(self, widget, data=None):
        self.builder.get_object('filechooserdialog').hide()
        return True

    def load_advanced(self):
        li_content = []
        self.category = 'advanced'
        self.home_file = os.path.join(HOME_DIR, '.lxde-ctrl-center/items/' + self.category)
        self.base_file = os.path.join(LIB_DIR, 'items', self.category)
        if os.path.isfile(self.home_file):
            self.category_file = self.home_file
        else:
            self.category_file = self.base_file
        with open(self.category_file, 'r') as items_file:
            dic = json.load(items_file)
        for k in dic:
            command = k
            title = dic[k]['title']
            owner = dic[k]['owner']
            icon = dic[k]['icon']
            if not os.path.isfile(icon):
               icon = LIB_DIR + '/icons/' + icon
            if not os.path.isfile(icon):
                icon = os.path.join(LIB_DIR, 'frontend/images/applications-other.svg')
            if OWNER == 'root' and owner == 'user':
                continue
            content = "<li id='" + command + "' onclick='javascript:changeTitle(\"exec:" + command + "\")' class='item' style='background-image: url(" + icon + ")'>" + _(title) + "</li>"
            li_content.append(content)
            self.items_cache.append(command)
        self.text['li_content'] = '\n'.join(li_content)

    def title_changed(self, view, frame, title):
        """Item clicked"""
        self.current_commands = []
        if title.startswith('exec:'):
            command = title.split(':', 1)[1]
            if self.commandSeek(command.split()[0].strip()):
                # res = subprocess.call('%s' % command, shell=True)
                p = subprocess.Popen('%s' % command, shell=True)
                # if res and not command.startswith(('xroot', 'kdesu')):
                #     message = MessageDialog('Error', _('Error! Cannot execute command <b>%s</b>!') % command, gtk.MESSAGE_ERROR)
                #     message.show()
            else:
                message = MessageDialog('Error', _('The command <b>%s</b> is not found or not is executable') % command, gtk.MESSAGE_ERROR)
                message.show()
        elif title.startswith('category:'):
            self.category = title.split(':')[1]
            self.home_file = os.path.join(HOME_DIR, '.lxde-ctrl-center/items/' + self.category)
            self.base_file = os.path.join(LIB_DIR, 'items', self.category)
            if os.path.isfile(self.home_file):
                self.category_file = self.home_file
            else:
                self.category_file = self.base_file
            with open(self.category_file, 'r') as items_file:
                dic = json.load(items_file)
            for k in dic:
                self.current_commands.append(k)
                command = k
                title = dic[k]['title']
                owner = dic[k]['owner']
                icon = dic[k]['icon']
                if not os.path.isfile(icon):
                   icon = LIB_DIR + '/icons/' + icon
                if not os.path.isfile(icon):
                    icon = os.path.join(LIB_DIR, 'frontend/images/applications-other.svg')
                if OWNER == 'root' and owner == 'user':
                    continue
                if command not in self.items_cache:
                           self.items_cache.append(command)
                           self.browser.execute_script("addItem('%s','%s','%s','%s')" % (_(title), command, self.category, icon))
            self.browser.execute_script("setContent('" + self.category + "')")
        elif title == 'edit-item':
            self.items_window(self)
        elif title.startswith('save-options:'):
            self.mode = title.split(':')[1]
            self.visual_effects = title.split(':')[2]
            self.save_preferences(self)
            for i in self.current_commands:
                if i in self.items_cache:
                    self.items_cache.remove(i)
            self.change_skin(self)

    def commandSeek(self, command):
        path, fname = os.path.split(command)
        result = []
        if path:
            if os.path.isfile(command) and os.access(command, os.X_OK):
                result.append(command)
        else:
            for path in os.environ["PATH"].split(os.pathsep):
                f = os.path.join(path, command)
                if os.path.isfile(f) and os.access(f, os.X_OK):
                    result.append(f)
        return result



if __name__ == '__main__':
    home_path = os.path.join(HOME_DIR, '.lxde-ctrl-center/items')
    if not os.path.exists(home_path):
        os.system('mkdir -p ' + home_path)
    gtk.gdk.threads_init()
    ControlCenter()
    gtk.main()
