Use spec from Mageia or from ROSA. 
