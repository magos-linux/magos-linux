#!/bin/bash
sed -i /drakgw/d usr/share/magos-ctrl-center/items/advanced
sed -i /drakgw/d usr/share/magos-ctrl-center/items/x0002x
