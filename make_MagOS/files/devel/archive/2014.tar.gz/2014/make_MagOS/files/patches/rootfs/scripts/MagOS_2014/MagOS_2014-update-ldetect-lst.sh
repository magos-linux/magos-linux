#!/bin/sh
LANG=C chroot ./ /usr/sbin/update-ldetect-lst
exit 0
