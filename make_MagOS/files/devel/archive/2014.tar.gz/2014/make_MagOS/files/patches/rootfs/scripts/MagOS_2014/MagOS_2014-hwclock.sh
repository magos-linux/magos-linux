#!/bin/bash
rm -f etc/adjtime
