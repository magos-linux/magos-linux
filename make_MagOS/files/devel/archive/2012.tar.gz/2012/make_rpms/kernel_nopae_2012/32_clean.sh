#!/bin/bash
rm -fr builddeps cache rpmbuild srpms rpms xzmbuild
