#!/bin/sh
chroot ./ /usr/sbin/update-ldetect-lst
exit 0
