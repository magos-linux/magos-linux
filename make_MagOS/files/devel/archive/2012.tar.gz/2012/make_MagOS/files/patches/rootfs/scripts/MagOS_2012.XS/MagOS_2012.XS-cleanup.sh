#!/bin/bash
rm -fr boot/pxelinux* etc/rc.d/init.d/ntlmaps usr/share/magos/screensaver/Russia-2011 usr/share/magos/wallpapers/fantasy  \
    usr/share/magos/wallpapers/simple/B*.jpg usr/share/magos/wallpapers/simple/K*.jpg usr/share/magos/wallpapers/simple/bluesth-*.jpg \
    usr/share/apps/ksplash usr/lib/magos/scripts/mkinitrd
