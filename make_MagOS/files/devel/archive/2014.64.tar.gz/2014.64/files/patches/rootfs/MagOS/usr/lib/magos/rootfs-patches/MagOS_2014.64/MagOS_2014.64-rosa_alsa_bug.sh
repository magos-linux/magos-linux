#!/bin/sh
sed -i /'hint.description "Direct control device"'/d /usr/share/alsa/alsa.conf
