#!/bin/bash
ln -sf fb0 lib/udev/devices/fb
exit 0
