#!/bin/bash
mkdir -m 755 -p run/udev/rules.d run/lock
exit 0
