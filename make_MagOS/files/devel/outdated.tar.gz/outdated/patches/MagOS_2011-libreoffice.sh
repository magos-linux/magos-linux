#!/bin/bash
sed -i 's|.*PSLevel=.*|PSLevel=1|' usr/lib/libreoffice/share/psprint/psprint.conf
