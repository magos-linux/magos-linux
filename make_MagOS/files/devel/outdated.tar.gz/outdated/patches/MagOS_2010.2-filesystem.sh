#!/bin/bash
rm -fr  usr/share/applications/kde4/Welcome.desktop usr/share/vpnpptp/wiki/Help_uk.doc  2>/dev/null
exit 0
