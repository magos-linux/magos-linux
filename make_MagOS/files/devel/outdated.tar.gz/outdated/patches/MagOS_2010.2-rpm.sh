#!/bin/bash
chroot ./ rpm --rebuilddb
