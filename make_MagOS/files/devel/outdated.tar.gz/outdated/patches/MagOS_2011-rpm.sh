#!/bin/bash
chroot ./ /usr/lib/rpm/bin/dbconvert
