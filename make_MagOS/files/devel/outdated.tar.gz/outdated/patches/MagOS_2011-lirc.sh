#!/bin/bash
sed -i 's|lirc/|lirc|' etc/udev/rules.d/lirc.rules
